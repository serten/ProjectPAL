package com.example.googleMaps;

import android.app.Fragment;

public class FragmentAlertZone1 extends Fragment{

}
